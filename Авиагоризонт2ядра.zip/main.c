#include "bmcu_common.h"

#include "bmcu_cru.h"

#include "bmcu_gpio.h"

#include "bmcu_i2c.h"

#include "bmcu_eflash.h"

#include <stdint.h>

#include <stddef.h>

/*
 * EVU-BA-2.5: авиагоризонт на ST7735 и MPU6050.
 * C0 рисует дисплей, C1 читает датчик.
 * ST7735: PB0 CS, PB1 SCK, PB3 MOSI, PB4 DC, PB5 RESET.
 * MPU6050: PA14 SCL, PA15 SDA, AD0 на GND.
 */

#define TFT_PORT GPIO1

#define TFT_CS   CRU_PIN_0

#define TFT_SCK  CRU_PIN_1

#define TFT_MOSI CRU_PIN_3

#define TFT_DC   CRU_PIN_4

#define TFT_RST  CRU_PIN_5

#define TFT_W 128

#define TFT_H 160

/* Регистры MPU6050 */

#define MPU_ADDR          0x68U

#define MPU_SMPLRT_DIV    0x19U

#define MPU_CONFIG        0x1AU

#define MPU_GYRO_CONFIG   0x1BU

#define MPU_ACCEL_CONFIG  0x1CU

#define MPU_ACCEL_XOUT_H  0x3BU

#define MPU_PWR_MGMT_1    0x6BU

#define MPU_WHO_AM_I      0x75U

/* Цвета RGB565 */

#define BLACK       0x0000

#define WHITE       0xFFFF

#define RED         0xF800

#define GREEN       0x07E0

#define BLUE        0x001F

#define YELLOW      0xFFE0

#define CYAN        0x07FF

#define ORANGE      0xFD20

/* Цвета авиагоризонта */

#define SKY         0x041F

#define SKY_LIGHT   0x05FF

#define GROUND      0x8200

#define GROUND_DARK 0x6180

/* Тактирование */

static void clk_init(void)

{

    CRU_PLL_BypassMode_Disable();

    CRU_PLL_SetSource(CRU_PLL_SRC_C0);

    CRU_PLL_ForceReset();

    CRU_PLL_Config(1UL, 48UL, 6UL, 48UL);

    CRU_PLL_ReleaseReset();

    __delay_cycles(500UL);

    CRU_SetCCLKPrescaler(CRU_CLK_DIV_1);

    CRU_CCLKPrescaler_Enable();

    CRU_SetCCLKSource(CRU_CLK_SRC_PLL);

    CRU_SetPCLK0Prescaler(CRU_CLK_DIV_2);

    CRU_PCLK0Prescaler_Enable();

    CRU_SetPCLK0Source(CRU_CLK_SRC_PLL);

    CRU_SetPCLK1Prescaler(CRU_CLK_DIV_2);

    CRU_PCLK1Prescaler_Enable();

    CRU_SetPCLK1Source(CRU_CLK_SRC_PLL);

    CRU_SetPCLK2Prescaler(CRU_CLK_DIV_2);

    CRU_PCLK2Prescaler_Enable();

    CRU_SetPCLK2Source(CRU_CLK_SRC_PLL);

    CRU_SetHCLKPrescaler(CRU_CLK_DIV_2);

    CRU_HCLKPrescaler_Enable();

    CRU_SetHCLKSource(CRU_CLK_SRC_PLL);

    CRU_SetCCLK1MHzPrescaler(199UL);

    CRU_SetHCLK1MHzPrescaler(99UL);

}

/* GPIO дисплея */

static void tft_gpio_init(void)

{

    CRU_PIN_InitStruct_TypeDef pin;

    CRU_PIN_StructInit(&pin);

    pin.Port          = CRU_PORT_B;

    pin.Pull          = CRU_PIN_PULL_NO;

    pin.InputCtrl     = DISABLE;

    pin.DriveStrength = CRU_PIN_DRIVE_STRENGTH_3;

    pin.Alternate     = CRU_PIN_AF_0;

    pin.Pin = CRU_PIN_0;

    CRU_PIN_Init(&pin);

    pin.Pin = CRU_PIN_1;

    CRU_PIN_Init(&pin);

    pin.Pin = CRU_PIN_3;

    CRU_PIN_Init(&pin);

    pin.Pin = CRU_PIN_4;

    CRU_PIN_Init(&pin);

    pin.Pin = CRU_PIN_5;

    CRU_PIN_Init(&pin);

    GPIO_SetPinMode(TFT_PORT, TFT_CS,   GPIO_MODE_OUTPUT);

    GPIO_SetPinMode(TFT_PORT, TFT_SCK,  GPIO_MODE_OUTPUT);

    GPIO_SetPinMode(TFT_PORT, TFT_MOSI, GPIO_MODE_OUTPUT);

    GPIO_SetPinMode(TFT_PORT, TFT_DC,   GPIO_MODE_OUTPUT);

    GPIO_SetPinMode(TFT_PORT, TFT_RST,  GPIO_MODE_OUTPUT);

    GPIO_SetOutputPin(TFT_PORT, TFT_CS);

    GPIO_ResetOutputPin(TFT_PORT, TFT_SCK);

    GPIO_ResetOutputPin(TFT_PORT, TFT_MOSI);

    GPIO_SetOutputPin(TFT_PORT, TFT_DC);

    GPIO_SetOutputPin(TFT_PORT, TFT_RST);

}

static inline void cs_low(void)

{

    GPIO_ResetOutputPin(TFT_PORT, TFT_CS);

}

static inline void cs_high(void)

{

    GPIO_SetOutputPin(TFT_PORT, TFT_CS);

}

static inline void dc_low(void)

{

    GPIO_ResetOutputPin(TFT_PORT, TFT_DC);

}

static inline void dc_high(void)

{

    GPIO_SetOutputPin(TFT_PORT, TFT_DC);

}

/* Программный SPI */

static void spi_write8(uint8_t data)

{

    for (uint8_t i = 0; i < 8; i++)

    {

        if (data & 0x80U)

            GPIO_SetOutputPin(TFT_PORT, TFT_MOSI);

        else

            GPIO_ResetOutputPin(TFT_PORT, TFT_MOSI);

        GPIO_SetOutputPin(TFT_PORT, TFT_SCK);

        __delay_cycles(10);

        GPIO_ResetOutputPin(TFT_PORT, TFT_SCK);

        data <<= 1;

    }

}

/* ST7735 */

static void tft_cmd(uint8_t cmd)

{

    dc_low();

    cs_low();

    spi_write8(cmd);

    cs_high();

}

static void tft_data(uint8_t data)

{

    dc_high();

    cs_low();

    spi_write8(data);

    cs_high();

}

static void tft_reset(void)

{

    GPIO_SetOutputPin(TFT_PORT, TFT_RST);

    __delay_ms(20);

    GPIO_ResetOutputPin(TFT_PORT, TFT_RST);

    __delay_ms(50);

    GPIO_SetOutputPin(TFT_PORT, TFT_RST);

    __delay_ms(150);

}

static void tft_init(void)

{

    tft_gpio_init();

    tft_reset();

    tft_cmd(0x01);

    __delay_ms(150);

    tft_cmd(0x11);

    __delay_ms(150);

    tft_cmd(0x3A);

    tft_data(0x05);

    tft_cmd(0x36);

    tft_data(0x00);

    tft_cmd(0x13);

    __delay_ms(10);

    tft_cmd(0x29);

    __delay_ms(100);

}

static void tft_window(

    uint16_t x0,

    uint16_t y0,

    uint16_t x1,

    uint16_t y1)

{

    tft_cmd(0x2A);

    tft_data((uint8_t)(x0 >> 8));

    tft_data((uint8_t)x0);

    tft_data((uint8_t)(x1 >> 8));

    tft_data((uint8_t)x1);

    tft_cmd(0x2B);

    tft_data((uint8_t)(y0 >> 8));

    tft_data((uint8_t)y0);

    tft_data((uint8_t)(y1 >> 8));

    tft_data((uint8_t)y1);

    tft_cmd(0x2C);

}

static void tft_fill(uint16_t color)

{

    uint32_t count = TFT_W * TFT_H;

    tft_window(0, 0, TFT_W - 1, TFT_H - 1);

    dc_high();

    cs_low();

    while (count--)

    {

        spi_write8((uint8_t)(color >> 8));

        spi_write8((uint8_t)color);

    }

    cs_high();

}

static void tft_pixel(

    int16_t x,

    int16_t y,

    uint16_t color)

{

    if (x < 0 || y < 0)

        return;

    if (x >= TFT_W || y >= TFT_H)

        return;

    tft_window(

        (uint16_t)x,

        (uint16_t)y,

        (uint16_t)x,

        (uint16_t)y);

    dc_high();

    cs_low();

    spi_write8((uint8_t)(color >> 8));

    spi_write8((uint8_t)color);

    cs_high();

}

/* Быстрая заливка прямоугольника */

static void tft_rect(

    int16_t x,

    int16_t y,

    int16_t w,

    int16_t h,

    uint16_t color)

{

    if (w <= 0 || h <= 0)

        return;

    if (x < 0)

    {

        w += x;

        x = 0;

    }

    if (y < 0)

    {

        h += y;

        y = 0;

    }

    if (x + w > TFT_W)

        w = TFT_W - x;

    if (y + h > TFT_H)

        h = TFT_H - y;

    if (w <= 0 || h <= 0)

        return;

    uint32_t count =

        (uint32_t)w *

        (uint32_t)h;

    tft_window(

        (uint16_t)x,

        (uint16_t)y,

        (uint16_t)(x + w - 1),

        (uint16_t)(y + h - 1));

    dc_high();

    cs_low();

    while (count--)

    {

        spi_write8((uint8_t)(color >> 8));

        spi_write8((uint8_t)color);

    }

    cs_high();

}

/* Линии */

static int16_t abs16(int16_t x)

{

    return (x < 0) ? -x : x;

}

static void tft_line(

    int16_t x0,

    int16_t y0,

    int16_t x1,

    int16_t y1,

    uint16_t color)

{

    int16_t dx = abs16(x1 - x0);

    int16_t sx = x0 < x1 ? 1 : -1;

    int16_t dy = -abs16(y1 - y0);

    int16_t sy = y0 < y1 ? 1 : -1;

    int16_t err = dx + dy;

    while (1)

    {

        tft_pixel(x0, y0, color);

        if (x0 == x1 && y0 == y1)

            break;

        int16_t e2 = 2 * err;

        if (e2 >= dy)

        {

            err += dy;

            x0 += sx;

        }

        if (e2 <= dx)

        {

            err += dx;

            y0 += sy;

        }

    }

}

/* Шрифт 5x7 */

typedef struct

{

    char c;

    uint8_t data[5];

} FontChar;

static const FontChar font[] =

{

    {' ', {0x00,0x00,0x00,0x00,0x00}},

    {'0', {0x3E,0x51,0x49,0x45,0x3E}},

    {'1', {0x00,0x42,0x7F,0x40,0x00}},

    {'2', {0x42,0x61,0x51,0x49,0x46}},

    {'3', {0x21,0x41,0x45,0x4B,0x31}},

    {'4', {0x18,0x14,0x12,0x7F,0x10}},

    {'5', {0x27,0x45,0x45,0x45,0x39}},

    {'6', {0x3C,0x4A,0x49,0x49,0x30}},

    {'7', {0x01,0x71,0x09,0x05,0x03}},

    {'8', {0x36,0x49,0x49,0x49,0x36}},

    {'9', {0x06,0x49,0x49,0x29,0x1E}},

    {'A', {0x7E,0x11,0x11,0x11,0x7E}},

    {'B', {0x7F,0x49,0x49,0x49,0x36}},

    {'C', {0x3E,0x41,0x41,0x41,0x22}},

    {'D', {0x7F,0x41,0x41,0x22,0x1C}},

    {'E', {0x7F,0x49,0x49,0x49,0x41}},

    {'F', {0x7F,0x09,0x09,0x09,0x01}},

    {'G', {0x3E,0x41,0x49,0x49,0x7A}},

    {'H', {0x7F,0x08,0x08,0x08,0x7F}},

    {'I', {0x00,0x41,0x7F,0x41,0x00}},

    {'K', {0x7F,0x08,0x14,0x22,0x41}},

    {'L', {0x7F,0x40,0x40,0x40,0x40}},

    {'M', {0x7F,0x02,0x0C,0x02,0x7F}},

    {'N', {0x7F,0x04,0x08,0x10,0x7F}},

    {'O', {0x3E,0x41,0x41,0x41,0x3E}},

    {'P', {0x7F,0x09,0x09,0x09,0x06}},

    {'R', {0x7F,0x09,0x19,0x29,0x46}},

    {'S', {0x46,0x49,0x49,0x49,0x31}},

    {'T', {0x01,0x01,0x7F,0x01,0x01}},

    {'U', {0x3F,0x40,0x40,0x40,0x3F}},

    {'V', {0x1F,0x20,0x40,0x20,0x1F}},

    {'X', {0x63,0x14,0x08,0x14,0x63}},

    {'Y', {0x03,0x04,0x78,0x04,0x03}},

    {'Z', {0x61,0x51,0x49,0x45,0x43}},

    {':', {0x00,0x36,0x36,0x00,0x00}},

    {'-', {0x08,0x08,0x08,0x08,0x08}},

    {'+', {0x08,0x08,0x3E,0x08,0x08}},

    {'.', {0x00,0x60,0x60,0x00,0x00}},

    {'/', {0x20,0x10,0x08,0x04,0x02}}

};

#define FONT_COUNT (sizeof(font) / sizeof(font[0]))

static const uint8_t *font_get(char c)

{

    for (size_t i = 0; i < FONT_COUNT; i++)

    {

        if (font[i].c == c)

            return font[i].data;

    }

    return font[0].data;

}

static void tft_char(

    uint16_t x,

    uint16_t y,

    char c,

    uint16_t color,

    uint16_t bg,

    uint8_t scale)

{

    const uint8_t *glyph =

        font_get(c);

    for (uint8_t col = 0; col < 5; col++)

    {

        uint8_t bits = glyph[col];

        for (uint8_t row = 0; row < 7; row++)

        {

            uint16_t pcolor =

                (bits & (1U << row))

                ? color

                : bg;

            for (uint8_t sx = 0;

                 sx < scale;

                 sx++)

            {

                for (uint8_t sy = 0;

                     sy < scale;

                     sy++)

                {

                    tft_pixel(

                        x + col * scale + sx,

                        y + row * scale + sy,

                        pcolor);

                }

            }

        }

    }

    for (uint8_t sy = 0;

         sy < 7 * scale;

         sy++)

    {

        for (uint8_t sx = 0;

             sx < scale;

             sx++)

        {

            tft_pixel(

                x + 5 * scale + sx,

                y + sy,

                bg);

        }

    }

}

static void tft_text(

    uint16_t x,

    uint16_t y,

    const char *text,

    uint16_t color,

    uint16_t bg,

    uint8_t scale)

{

    while (*text)

    {

        tft_char(

            x,

            y,

            *text,

            color,

            bg,

            scale);

        x += 6U * scale;

        text++;

    }

}

/* Перевод числа в строку */

static void int_to_text(

    int32_t value,

    char *buffer)

{

    char temp[12];

    uint32_t number;

    int i = 0;

    int p = 0;

    if (value < 0)

    {

        buffer[p++] = '-';

        number = (uint32_t)(-value);

    }

    else

    {

        buffer[p++] = '+';

        number = (uint32_t)value;

    }

    if (number == 0)

    {

        buffer[p++] = '0';

        buffer[p] = '\0';

        return;

    }

    while (number > 0)

    {

        temp[i++] =

            (char)('0' + (number % 10U));

        number /= 10U;

    }

    while (i > 0)

    {

        buffer[p++] =

            temp[--i];

    }

    buffer[p] = '\0';

}

/* I2C1: PA14 — SCL, PA15 — SDA */

static void i2c1_init(void)

{

    CRU_PIN_InitStruct_TypeDef pin;

    I2C_InitStruct_TypeDef i2c;

    CRU_APB0_EnableClock(

        CRU_APB0_PERIPH_I2C1);

    CRU_PIN_StructInit(&pin);

    pin.Port          = CRU_PORT_A;

    pin.Pin           = CRU_PIN_14;

    pin.Pull          = CRU_PIN_PULL_UP;

    pin.InputCtrl     = ENABLE;

    pin.DriveStrength =

        CRU_PIN_DRIVE_STRENGTH_0;

    pin.Alternate =

        CRU_PIN_AF_2;

    CRU_PIN_Init(&pin);

    pin.Pin = CRU_PIN_15;

    CRU_PIN_Init(&pin);

    I2C_StructInit(&i2c);

    I2C_Init(I2C1, &i2c);

    I2C_Enable(I2C1);

}

/* Ожидание I2C */

static int i2c_wait_tfnf(void)

{

    uint32_t timeout =

        1000000UL;

    while (timeout--)

    {

        if (I2C_IsActiveFlag(

                I2C1,

                I2C_FLAG_TFNF))

        {

            return 1;

        }

    }

    return 0;

}

static int i2c_wait_tfe(void)

{

    uint32_t timeout =

        1000000UL;

    while (timeout--)

    {

        if (I2C_IsActiveFlag(

                I2C1,

                I2C_FLAG_TFE))

        {

            return 1;

        }

    }

    return 0;

}

static int i2c_wait_rfne(void)

{

    uint32_t timeout =

        1000000UL;

    while (timeout--)

    {

        if (I2C_IsActiveFlag(

                I2C1,

                I2C_FLAG_RFNE))

        {

            return 1;

        }

    }

    return 0;

}

/* Запись в MPU6050 */

static int mpu_write_reg(

    uint8_t reg,

    uint8_t value)

{

    I2C1->TAR = MPU_ADDR;

    if (!i2c_wait_tfnf())

        return 0;

    I2C_TransmitData(

        I2C1,

        reg,

        I2C_FLAG_CMD_WRITE);

    if (!i2c_wait_tfnf())

        return 0;

    I2C_TransmitData(

        I2C1,

        value,

        I2C_FLAG_CMD_WRITE);

    if (!i2c_wait_tfe())

        return 0;

    __delay_ms(2);

    return 1;

}

/* Чтение регистра MPU6050 */

static int mpu_read_reg(

    uint8_t reg,

    uint8_t *value)

{

    I2C1->TAR = MPU_ADDR;

    if (!i2c_wait_tfnf())

        return 0;

    I2C_TransmitData(

        I2C1,

        reg,

        I2C_FLAG_CMD_WRITE);

    if (!i2c_wait_tfe())

        return 0;

    if (!i2c_wait_tfnf())

        return 0;

    I2C_TransmitData(

        I2C1,

        0x00,

        I2C_FLAG_CMD_READ);

    if (!i2c_wait_rfne())

        return 0;

    *value =

        I2C_ReceiveData(I2C1);

    return 1;

}

/* Чтение нескольких байт */

static int mpu_read_bytes(

    uint8_t reg,

    uint8_t *buffer,

    uint8_t length)

{

    I2C1->TAR = MPU_ADDR;

    if (!i2c_wait_tfnf())

        return 0;

    I2C_TransmitData(

        I2C1,

        reg,

        I2C_FLAG_CMD_WRITE);

    if (!i2c_wait_tfe())

        return 0;

    for (uint8_t i = 0;

         i < length;

         i++)

    {

        if (!i2c_wait_tfnf())

            return 0;

        I2C_TransmitData(

            I2C1,

            0x00,

            I2C_FLAG_CMD_READ);

    }

    for (uint8_t i = 0;

         i < length;

         i++)

    {

        if (!i2c_wait_rfne())

            return 0;

        buffer[i] =

            I2C_ReceiveData(I2C1);

    }

    return 1;

}

/* Настройка MPU6050 */

static int mpu_init(uint8_t *who)

{

    *who = 0;

    __delay_ms(100);

    if (!mpu_read_reg(

            MPU_WHO_AM_I,

            who))

    {

        return 0;

    }

    if (*who != 0x68U)

        return 0;

    if (!mpu_write_reg(

            MPU_PWR_MGMT_1,

            0x00))

    {

        return 0;

    }

    __delay_ms(100);

    mpu_write_reg(

        MPU_SMPLRT_DIV,

        0x07);

    mpu_write_reg(

        MPU_CONFIG,

        0x03);

    /* Гироскоп: ±250 град/с */

    mpu_write_reg(

        MPU_GYRO_CONFIG,

        0x00);

    /* Акселерометр: ±2g */

    mpu_write_reg(

        MPU_ACCEL_CONFIG,

        0x00);

    return 1;

}

/* Данные MPU6050 */

typedef struct

{

    int16_t ax;

    int16_t ay;

    int16_t az;

    int16_t temp;

    int16_t gx;

    int16_t gy;

    int16_t gz;

} MPU_Data;

static int mpu_read_all(

    MPU_Data *data)

{

    uint8_t b[14];

    if (!mpu_read_bytes(

            MPU_ACCEL_XOUT_H,

            b,

            14))

    {

        return 0;

    }

    data->ax =

        (int16_t)(

            ((uint16_t)b[0] << 8) |

            b[1]);

    data->ay =

        (int16_t)(

            ((uint16_t)b[2] << 8) |

            b[3]);

    data->az =

        (int16_t)(

            ((uint16_t)b[4] << 8) |

            b[5]);

    data->temp =

        (int16_t)(

            ((uint16_t)b[6] << 8) |

            b[7]);

    data->gx =

        (int16_t)(

            ((uint16_t)b[8] << 8) |

            b[9]);

    data->gy =

        (int16_t)(

            ((uint16_t)b[10] << 8) |

            b[11]);

    data->gz =

        (int16_t)(

            ((uint16_t)b[12] << 8) |

            b[13]);

    return 1;

}


static int32_t abs32(

    int32_t value)

{

    if (value < 0)

        return -value;

    return value;

}

static int16_t clamp_angle(

    int32_t value)

{

    if (value > 45)

        value = 45;

    if (value < -45)

        value = -45;

    return (int16_t)value;

}

static int16_t calc_roll(

    const MPU_Data *s)

{

    int32_t y =

        (int32_t)s->ay;

    int32_t z =

        (int32_t)s->az;

    int32_t denominator =

        abs32(y) +

        abs32(z);

    if (denominator < 100)

        denominator = 100;

    /* Угол считаю приближённо — для авиагоризонта этого хватает. */

    int32_t angle =

        (y * 90) /

        denominator;

    return clamp_angle(angle);

}

static int16_t calc_pitch(

    const MPU_Data *s)

{

    int32_t x =

        (int32_t)s->ax;

    int32_t y =

        (int32_t)s->ay;

    int32_t z =

        (int32_t)s->az;

    int32_t denominator =

        abs32(x) +

        abs32(y) +

        abs32(z);

    if (denominator < 100)

        denominator = 100;

    int32_t angle =

        (-x * 90) /

        denominator;

    return clamp_angle(angle);

}

/* Простое сглаживание */

static int16_t filter_angle(

    int16_t old_value,

    int16_t new_value)

{

    return (int16_t)(

        (

            (int32_t)old_value * 3 +

            (int32_t)new_value

        ) / 4);

}

/* Фон горизонта выводим одним потоком пикселей — так быстрее. */

#define HUD_TOP    18

#define HUD_BOTTOM 124

static void draw_horizon(

    int16_t roll,

    int16_t pitch)

{

    int16_t center_y =

        70 + pitch;

    tft_window(

        0,

        HUD_TOP,

        127,

        HUD_BOTTOM);

    dc_high();

    cs_low();

    for (int16_t y = HUD_TOP;

         y <= HUD_BOTTOM;

         y++)

    {

        for (int16_t x = 0;

             x < 128;

             x++)

        {

            /* При 45° крена перепад по краям получается примерно 32 пикселя. */

            int32_t slope =

                ((int32_t)(x - 64) *

                 (int32_t)roll) /

                90;

            int16_t horizon_y =

                center_y +

                (int16_t)slope;

            uint16_t color;

            if (y < horizon_y - 1)

            {

                color = SKY;

            }

            else if (y > horizon_y + 1)

            {

                color = GROUND;

            }

            else

            {

                color = WHITE;

            }

            spi_write8(

                (uint8_t)(color >> 8));

            spi_write8(

                (uint8_t)color);

        }

    }

    cs_high();

}

/* Метка самолёта */

static void draw_aircraft(void)

{

    const int16_t cx = 64;

    const int16_t cy = 72;

    /* Центральный символ самолёта. */

    /* Левое крыло */

    tft_line(

        cx - 28,

        cy,

        cx - 7,

        cy,

        YELLOW);

    tft_line(

        cx - 28,

        cy + 1,

        cx - 7,

        cy + 1,

        YELLOW);

    /* Правое крыло */

    tft_line(

        cx + 7,

        cy,

        cx + 28,

        cy,

        YELLOW);

    tft_line(

        cx + 7,

        cy + 1,

        cx + 28,

        cy + 1,

        YELLOW);

    /* Центр */

    tft_line(

        cx - 7,

        cy,

        cx,

        cy + 5,

        YELLOW);

    tft_line(

        cx,

        cy + 5,

        cx + 7,

        cy,

        YELLOW);

    /* Центральная метка */

    tft_rect(

        cx - 2,

        cy - 2,

        5,

        5,

        YELLOW);

}

/* Шкала крена */

static void draw_roll_scale(

    int16_t roll)

{

    /* Верхняя шкала крена. */

    tft_line(

        34, 26,

        94, 26,

        WHITE);

    tft_line(

        34, 26,

        34, 30,

        WHITE);

    tft_line(

        49, 26,

        49, 29,

        WHITE);

    tft_line(

        64, 26,

        64, 31,

        WHITE);

    tft_line(

        79, 26,

        79, 29,

        WHITE);

    tft_line(

        94, 26,

        94, 30,

        WHITE);

    /* Крены от -45° до 45° переводим в x=34..94. */

    int16_t marker =

        64 +

        (int16_t)(

            ((int32_t)roll * 30) /

            45);

    if (marker < 34)

        marker = 34;

    if (marker > 94)

        marker = 94;

    tft_line(

        marker,

        31,

        marker - 3,

        35,

        RED);

    tft_line(

        marker,

        31,

        marker + 3,

        35,

        RED);

    tft_line(

        marker - 3,

        35,

        marker + 3,

        35,

        RED);

}

static void draw_pitch_marks(

    int16_t pitch)

{

    int16_t base =

        72 + pitch;

    for (int16_t p = -20;

         p <= 20;

         p += 10)

    {

        int16_t y =

            base + p;

        if (y < 38 ||

            y > 112)

        {

            continue;

        }

        int16_t half;

        if (p == 0)

            half = 20;

        else

            half = 9;

        tft_line(

            64 - half,

            y,

            64 + half,

            y,

            WHITE);

    }

}

/* Вывод значений */

static void show_angle(

    uint16_t x,

    uint16_t y,

    int16_t value,

    uint16_t color)

{

    char text[12];

    int_to_text(

        value,

        text);

    /* Стираем предыдущее значение. */

    tft_rect(

        x,

        y,

        35,

        8,

        BLACK);

    tft_text(

        x,

        y,

        text,

        color,

        BLACK,

        1);

}

/* Неподвижная часть интерфейса */

static void draw_hud_frame(void)

{

    /* Верхняя панель */

    tft_rect(

        0,

        0,

        128,

        18,

        BLACK);

    tft_text(

        3,

        4,

        "MPU6050",

        CYAN,

        BLACK,

        1);

    tft_text(

        87,

        4,

        "I2C",

        GREEN,

        BLACK,

        1);

    /* Нижняя панель */

    tft_rect(

        0,

        125,

        128,

        35,

        BLACK);

    tft_text(

        4,

        130,

        "ROLL:",

        WHITE,

        BLACK,

        1);

    tft_text(

        4,

        143,

        "PITCH:",

        WHITE,

        BLACK,

        1);

    /* Центральная вертикальная риска */

    tft_line(

        64,

        67,

        64,

        77,

        YELLOW);

}

/* Экран ошибки */

static void show_mpu_error(void)

{

    tft_fill(BLACK);

    tft_text(

        8,

        20,

        "MPU6050",

        WHITE,

        BLACK,

        2);

    tft_text(

        20,

        55,

        "ERROR",

        RED,

        BLACK,

        2);

    tft_text(

        20,

        90,

        "CHECK I2C",

        YELLOW,

        BLACK,

        1);

}

/* Обмен между ядрами: C0 рисует, C1 работает с MPU6050. */

/* Для C1 нужен свой стек и gp — это подготавливает core1_entry.S. */

extern void core1_entry(void);

uint8_t core1_stack[4096] __attribute__((aligned(16)));
uintptr_t core1_stack_top = (uintptr_t)(core1_stack + sizeof(core1_stack));

volatile uint8_t shared_core1_alive = 0;
volatile uint8_t shared_core1_trap = 0;

static volatile int16_t shared_roll = 0;
static volatile int16_t shared_pitch = 0;
static volatile uint32_t shared_seq = 0;
static volatile uint8_t shared_mpu_ready = 0;
static volatile uint8_t shared_mpu_error = 0;
static volatile uint8_t shared_who_am_i = 0;

/* Счётчик не даёт C0 смешать roll и pitch от разных измерений. */

static void shared_publish_angles(int16_t roll, int16_t pitch)
{
    shared_seq++;
    __asm volatile ("fence rw, rw" ::: "memory");

    shared_roll = roll;
    shared_pitch = pitch;

    __asm volatile ("fence rw, rw" ::: "memory");
    shared_seq++;
}

static void shared_read_angles(int16_t *roll, int16_t *pitch)
{
    uint32_t seq_a = 0U;
    uint32_t seq_b = 0U;
    int16_t r = 0;
    int16_t p = 0;

    for (;;)
    {
        seq_a = shared_seq;

        if (seq_a & 1U)
            continue;

        __asm volatile ("fence rw, rw" ::: "memory");

        r = shared_roll;
        p = shared_pitch;

        __asm volatile ("fence rw, rw" ::: "memory");
        seq_b = shared_seq;

        if ((seq_a == seq_b) && ((seq_b & 1U) == 0U))
            break;
    }

    *roll = r;
    *pitch = p;
}

/* Ядро 1: только MPU6050 */

void core1_main(void)
{
    uint8_t who = 0;
    MPU_Data sensor;

    int16_t roll = 0;
    int16_t pitch = 0;
    int16_t roll_raw;
    int16_t pitch_raw;

    shared_core1_alive = 1U;
    __asm volatile ("fence rw, rw" ::: "memory");

    /* Общие тактовые частоты уже настроены ядром 0. */
    i2c1_init();
    __delay_ms(100);

    if (!mpu_init(&who))
    {
        shared_who_am_i = who;
        shared_mpu_error = 1;
        shared_mpu_ready = 0;

        for (;;)
        {
            __delay_ms(1000);
        }
    }

    shared_who_am_i = who;

    /* Первый корректный замер. */
    if (mpu_read_all(&sensor))
    {
        roll = calc_roll(&sensor);
        pitch = calc_pitch(&sensor);
        shared_publish_angles(roll, pitch);
        shared_mpu_ready = 1;
    }
    else
    {
        shared_mpu_error = 1;
    }

    for (;;)
    {
        if (mpu_read_all(&sensor))
        {
            roll_raw = calc_roll(&sensor);
            pitch_raw = calc_pitch(&sensor);

            roll = filter_angle(roll, roll_raw);
            pitch = filter_angle(pitch, pitch_raw);

            shared_publish_angles(roll, pitch);

            shared_mpu_error = 0;
            shared_mpu_ready = 1;
        }
        else
        {
            shared_mpu_error = 1;
        }

        /* Датчик обновляется отдельно от программного SPI дисплея. */
        __delay_ms(10);
    }
}

/* Ядро 0: только ST7735 */

int main(void)
{
    int16_t roll = 0;
    int16_t pitch = 0;
    uint8_t first_frame = 1;

    /* eFlash при CCLK 200 МГц */
    EFLASH_Init(200000000);
    clk_init();

    /* Дисплей обслуживает только ядро 0. */
    tft_init();
    tft_fill(BLACK);

    tft_text(8, 20, "FLIGHT", CYAN, BLACK, 2);
    tft_text(8, 42, "DISPLAY", CYAN, BLACK, 2);
    tft_text(25, 80, "MPU6050", WHITE, BLACK, 1);
    tft_text(30, 100, "CORE1...", YELLOW, BLACK, 1);

    /* Запускаем C1; I2C1 и MPU6050 он настраивает сам. */

    /* C1 стартует через core1_entry.S: там задаются gp и отдельный стек. */

    __asm volatile ("fence rw, rw" ::: "memory");
    CRU_C1_Start((uint32_t)core1_entry);

    for (;;)
    {
        if (shared_mpu_ready)
        {
            shared_read_angles(&roll, &pitch);

            if (first_frame)
            {
                tft_fill(BLACK);
                first_frame = 0;
            }

            /* Перерисовываем подвижную часть горизонта. */
            draw_horizon(roll, pitch);
            draw_roll_scale(roll);
            draw_pitch_marks(pitch);
            draw_aircraft();

            /* Верхняя строка. */
            tft_rect(0, 0, 128, 18, BLACK);
            tft_text(3, 4, "MPU6050", CYAN, BLACK, 1);

            if (shared_mpu_error)
                tft_text(81, 4, "ERR", RED, BLACK, 1);
            else
                tft_text(81, 4, "CORE1", GREEN, BLACK, 1);

            /* Нижняя информационная панель. */
            tft_rect(0, 125, 128, 35, BLACK);

            tft_text(4, 130, "ROLL:", WHITE, BLACK, 1);
            show_angle(43, 130, roll, CYAN);

            tft_text(4, 143, "PITCH:", WHITE, BLACK, 1);
            show_angle(49, 143, pitch, CYAN);
        }
        else if (shared_mpu_error)
        {
            show_mpu_error();

            /* При ошибке оставляем этот экран без перерисовки. */
            for (;;)
            {
                __delay_ms(1000);
            }
        }
        else
        {
            /* C1 уже запущено, MPU6050 ещё инициализируется. */
            if (shared_core1_trap)
            {
                tft_rect(20, 96, 100, 14, BLACK);
                tft_text(24, 100, "C1 TRAP", RED, BLACK, 1);
            }
            else if (shared_core1_alive)
            {
                tft_rect(20, 96, 100, 14, BLACK);
                tft_text(24, 100, "C1 RUN I2C", GREEN, BLACK, 1);
            }
            __delay_ms(10);
        }
    }

    return 0;
}
