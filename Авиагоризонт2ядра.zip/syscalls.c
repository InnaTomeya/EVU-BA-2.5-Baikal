#include <stddef.h>
#include <stdint.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>

int _close(int fd)
{
    (void)fd;
    return -1;
}

off_t _lseek(int fd, off_t offset, int whence)
{
    (void)fd;
    (void)offset;
    (void)whence;
    return (off_t)0;
}

int _read(int fd, char *ptr, int len)
{
    (void)fd;
    (void)ptr;
    (void)len;
    return 0;
}

int _write(int fd, const char *ptr, int len)
{
    (void)fd;
    (void)ptr;
    return len;
}

void _exit(int status)
{
    (void)status;
    for (;;) {
        __asm volatile ("nop");
    }
}

int _kill(int pid, int sig)
{
    (void)pid;
    (void)sig;
    return -1;
}

int _getpid(void)
{
    return 1;
}

int _fstat(int fd, struct stat *st)
{
    (void)fd;
    if (st != NULL) {
        st->st_mode = S_IFCHR;
    }
    return 0;
}

int _isatty(int fd)
{
    (void)fd;
    return 1;
}

void *_sbrk(ptrdiff_t increment)
{
    static union {
        unsigned long align;
        unsigned char bytes[2048];
    } heap;
    static ptrdiff_t used = 0;

    if (increment < 0 || increment > (ptrdiff_t)sizeof(heap.bytes) - used - 7) {
        errno = ENOMEM;
        return (void *)-1;
    }

    void *previous = (void *)(heap.bytes + used);
    used = (used + increment + 7) & ~(ptrdiff_t)7;
    return previous;
}
